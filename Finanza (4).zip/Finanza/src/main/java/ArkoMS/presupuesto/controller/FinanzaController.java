package ArkoMS.presupuesto.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import ArkoMS.presupuesto.model.Finanza;
import ArkoMS.presupuesto.dto.FinanzaRequestDTO;
import ArkoMS.presupuesto.service.FinanzaService;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@Transactional
@RequiredArgsConstructor
@RequestMapping("/api/presupuestos")
public class FinanzaController {
    private final FinanzaService presupuestoService;

    @GetMapping("gastos-mensuales")
    public ResponseEntity<?> gastosMensuales(@RequestParam String inicio, @RequestParam String fin) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat fmtMes = new SimpleDateFormat("yyyy-MM");
        try {
            Date dInicio = sdf.parse(inicio);
            Date dFin = sdf.parse(fin);
            List<Finanza> finanzas = presupuestoService.obtenerFinanzasEntreFechas(dInicio, dFin);

            Map<String, Integer> resultado = new LinkedHashMap<>();
            for (Finanza f : finanzas) {
                String mes = fmtMes.format(f.getFecha());
                Integer g = f.getGastos() == null ? 0 : f.getGastos();
                resultado.put(mes, resultado.getOrDefault(mes, 0) + g);
            }

            return ResponseEntity.ok(resultado);
        } catch (ParseException e) {
            return ResponseEntity.badRequest().body("Formato de fecha inválido. Use yyyy-MM-dd");
        }
    }

    @GetMapping("por-fecha")
   public ResponseEntity<?> obtenerPorFecha(@RequestParam String fecha) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    try {
        Date d = sdf.parse(fecha);
        List<Finanza> finanzas = presupuestoService.obtenerFinanzasPorFecha(d);
        return ResponseEntity.ok(finanzas);
    } catch (ParseException e) {
        return ResponseEntity.badRequest().body("Formato de fecha inválido. Use yyyy-MM-dd");
    }
}


    @GetMapping("todos")
    public ResponseEntity<?> obtenerTodas() {
        List<Finanza> finanzas = presupuestoService.obtenerTodasFinanzas();
        return ResponseEntity.ok(finanzas);
    }

    @PostMapping
    public ResponseEntity<?> crearFinanza(@Valid @RequestBody FinanzaRequestDTO dto) {
        Finanza finanza = presupuestoService.crearFinanza(dto);
        return ResponseEntity.status(201).body(finanza);
    }

    @PutMapping("{id}")
    public ResponseEntity<?> actualizarFinanza(@PathVariable Long id, @Valid @RequestBody FinanzaRequestDTO dto) {
        Finanza finanza = presupuestoService.actualizarFinanza(id, dto);
        return ResponseEntity.ok(finanza);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<?> eliminarFinanza(@PathVariable Long id) {
        boolean eliminado = presupuestoService.eliminarFinanza(id);
        if (!eliminado) {
            return ResponseEntity.status(404).body("Finanza no encontrada con ID: " + id);
        }
        return ResponseEntity.noContent().build();
    }

}