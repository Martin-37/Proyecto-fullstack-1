package ArkoMS.presupuesto.dto;

import lombok.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor   
public class FinanzaResponseDTO {
    
    private Long id;
    
    private Integer gastos;
    
    private Integer ingreso;
    
    private Date fecha;
    
    private String descripcion;
}
